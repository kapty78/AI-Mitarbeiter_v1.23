-- Show all companies
SELECT * FROM companies;

-- Show company with specific domain
SELECT * FROM companies WHERE domain = 'ecomtask.de'; 